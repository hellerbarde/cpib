
### R Markdown Example: Winter Olympics Medals
This is an updated version of a Sweave example showing how to implement the equivalent code using R Markdown.  For more information and details on the original post go to <http://jeromyanglim.blogspot.com>


## Licence
Licenced under the Simplified BSD License.
For more information on FreeBSD see: 
http://www.opensource.org/licenses/bsd-license.php
