Basic R Markdown example demonstrating basic functionality.
