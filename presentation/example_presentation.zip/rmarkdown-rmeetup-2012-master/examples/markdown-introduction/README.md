A simple example demonstrating many of the rules of markdown formatting.
