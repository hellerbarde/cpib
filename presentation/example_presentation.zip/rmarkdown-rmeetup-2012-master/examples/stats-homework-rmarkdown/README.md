An example of doing statistical homework with R Markdown.
